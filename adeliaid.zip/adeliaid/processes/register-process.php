<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/register.php');
}

// Verify CSRF token
if (!verifyCsrfToken($_POST['csrf_token'])) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Invalid CSRF token. Please try again.'
    ];
    redirect('pages/register.php');
}

// Sanitize inputs
$username = sanitizeInput($_POST['username']);
$whatsapp = sanitizeInput($_POST['whatsapp']);
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

// Validate inputs
$errors = [];

if (empty($username)) {
    $errors[] = 'Username is required.';
} elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    $errors[] = 'Username can only contain letters, numbers and underscores.';
} elseif (strlen($username) < 4) {
    $errors[] = 'Username must be at least 4 characters.';
}

if (empty($whatsapp)) {
    $errors[] = 'WhatsApp number is required.';
} elseif (!preg_match('/^[0-9]+$/', $whatsapp)) {
    $errors[] = 'WhatsApp number can only contain numbers.';
} elseif (strlen($whatsapp) < 10) {
    $errors[] = 'WhatsApp number is too short.';
}

if (empty($password)) {
    $errors[] = 'Password is required.';
} elseif (strlen($password) < 8) {
    $errors[] = 'Password must be at least 8 characters.';
} elseif ($password !== $confirm_password) {
    $errors[] = 'Passwords do not match.';
}

// Check if username already exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
$stmt->execute([$username]);
if ($stmt->fetch()) {
    $errors[] = 'Username already taken.';
}

if (!empty($errors)) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => implode('<br>', $errors)
    ];
    redirect('pages/register.php');
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Create user
try {
    $stmt = $pdo->prepare("
        INSERT INTO users (username, password, whatsapp, status) 
        VALUES (?, ?, ?, 'pending')
    ");
    $stmt->execute([$username, $hashed_password, $whatsapp]);
    
    // Send WhatsApp notification to admin
    $message = "New registration on AdeliaID:\nUsername: $username\nWhatsApp: $whatsapp\n\nPlease review in admin dashboard.";
    sendWhatsAppNotification(ADMIN_WHATSAPP, $message);
    
    $_SESSION['flash_message'] = [
        'type' => 'success',
        'text' => 'Registration successful! Your account is pending admin approval. You will be notified once approved.'
    ];
    redirect('pages/login.php');
} catch (PDOException $e) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Registration failed. Please try again.'
    ];
    redirect('pages/register.php');
}
?>