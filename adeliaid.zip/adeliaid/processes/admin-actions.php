<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Only admin can access this page
if (!isAdmin()) {
    redirect('../../login.php');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../../pages/dashboard/users.php');
}

// Verify CSRF token
if (!verifyCsrfToken($_POST['csrf_token'])) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Invalid CSRF token. Please try again.'
    ];
    redirect('../../pages/dashboard/users.php');
}

$action = $_POST['action'] ?? '';
$user_id = $_POST['user_id'] ?? 0;

// Get user details
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'User not found.'
    ];
    redirect('../../pages/dashboard/users.php');
}

// Perform action
try {
    $pdo->beginTransaction();
    
    switch ($action) {
        case 'approve':
            $stmt = $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?");
            $stmt->execute([$user_id]);
            
            // Log action
            logAdminAction($_SESSION['user_id'], 'Approved user', $user_id, "Username: {$user['username']}");
            
            // Send WhatsApp notification to user
            $message = "Your AdeliaID account has been approved!\n\nUsername: {$user['username']}\n\nYou can now login at: " . BASE_URL;
            sendWhatsAppNotification($user['whatsapp'], $message);
            
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'text' => "User {$user['username']} has been approved."
            ];
            break;
            
        case 'reject':
            $stmt = $pdo->prepare("UPDATE users SET status = 'rejected' WHERE id = ?");
            $stmt->execute([$user_id]);
            
            // Log action
            logAdminAction($_SESSION['user_id'], 'Rejected user', $user_id, "Username: {$user['username']}");
            
            // Send WhatsApp notification to user
            $message = "Your AdeliaID account registration has been rejected.\n\nUsername: {$user['username']}\n\nContact admin for more information.";
            sendWhatsAppNotification($user['whatsapp'], $message);
            
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'text' => "User {$user['username']} has been rejected."
            ];
            break;
            
        case 'activate':
            $stmt = $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?");
            $stmt->execute([$user_id]);
            
            // Log action
            logAdminAction($_SESSION['user_id'], 'Activated user', $user_id, "Username: {$user['username']}");
            
            // Send WhatsApp notification to user
            $message = "Your AdeliaID account has been activated!\n\nUsername: {$user['username']}\n\nYou can now login at: " . BASE_URL;
            sendWhatsAppNotification($user['whatsapp'], $message);
            
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'text' => "User {$user['username']} has been activated."
            ];
            break;
            
        case 'deactivate':
            $stmt = $pdo->prepare("UPDATE users SET status = 'inactive' WHERE id = ?");
            $stmt->execute([$user_id]);
            
            // Log action
            logAdminAction($_SESSION['user_id'], 'Deactivated user', $user_id, "Username: {$user['username']}");
            
            // Send WhatsApp notification to user
            $message = "Your AdeliaID account has been deactivated.\n\nUsername: {$user['username']}\n\nContact admin for more information.";
            sendWhatsAppNotification($user['whatsapp'], $message);
            
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'text' => "User {$user['username']} has been deactivated."
            ];
            break;
            
        case 'delete':
            if ($user['username'] === 'admin') {
                throw new Exception("Cannot delete admin user.");
            }
            
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            
            // Log action
            logAdminAction($_SESSION['user_id'], 'Deleted user', $user_id, "Username: {$user['username']}");
            
            $_SESSION['flash_message'] = [
                'type' => 'success',
                'text' => "User {$user['username']} has been deleted."
            ];
            break;
            
        default:
            throw new Exception("Invalid action.");
    }
    
    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => "Action failed: " . $e->getMessage()
    ];
}

redirect('../../pages/dashboard/users.php');

function logAdminAction($admin_id, $action, $target_user_id = null, $details = null) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        INSERT INTO admin_logs (admin_id, action, target_user_id, details)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$admin_id, $action, $target_user_id, $details]);
}
?>