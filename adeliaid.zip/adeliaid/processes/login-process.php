<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/login.php');
}

// Verify CSRF token
if (!verifyCsrfToken($_POST['csrf_token'])) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Invalid CSRF token. Please try again.'
    ];
    redirect('pages/login.php');
}

// Sanitize inputs
$username = sanitizeInput($_POST['username']);
$password = sanitizeInput($_POST['password']);

// Validate inputs
if (empty($username) || empty($password)) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Please fill in all fields.'
    ];
    redirect('pages/login.php');
}

// Check user credentials
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || !password_verify($password, $user['password'])) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Invalid username or password.'
    ];
    redirect('pages/login.php');
}

// Check if user is approved
if ($user['status'] !== 'active') {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Your account is not yet approved. Please wait for admin approval.'
    ];
    redirect('pages/login.php');
}

// Login successful
$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['is_admin'] = ($user['username'] === 'admin'); // In real app, you'd have a proper admin flag
$_SESSION['last_activity'] = time();

// Update last activity in database
$stmt = $pdo->prepare("UPDATE users SET last_activity = NOW() WHERE id = ?");
$stmt->execute([$user['id']]);

// Redirect to appropriate page
if ($_SESSION['is_admin']) {
    redirect('pages/dashboard/');
} else {
    redirect('index.php');
}
?>