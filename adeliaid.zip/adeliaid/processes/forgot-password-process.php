<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('pages/forgot-password.php');
}

// Verify CSRF token
if (!verifyCsrfToken($_POST['csrf_token'])) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Invalid CSRF token. Please try again.'
    ];
    redirect('pages/forgot-password.php');
}

// Sanitize inputs
$username = sanitizeInput($_POST['username']);
$whatsapp = sanitizeInput($_POST['whatsapp']);
$new_password = $_POST['new_password'];
$confirm_password = $_POST['confirm_password'];

// Validate inputs
$errors = [];

if (empty($username)) {
    $errors[] = 'Username is required.';
}

if (empty($whatsapp)) {
    $errors[] = 'WhatsApp number is required.';
} elseif (!preg_match('/^[0-9]+$/', $whatsapp)) {
    $errors[] = 'WhatsApp number can only contain numbers.';
}

if (empty($new_password)) {
    $errors[] = 'New password is required.';
} elseif (strlen($new_password) < 8) {
    $errors[] = 'Password must be at least 8 characters.';
} elseif ($new_password !== $confirm_password) {
    $errors[] = 'Passwords do not match.';
}

if (!empty($errors)) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => implode('<br>', $errors)
    ];
    redirect('pages/forgot-password.php');
}

// Verify user and WhatsApp number
$stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND whatsapp = ?");
$stmt->execute([$username, $whatsapp]);
$user = $stmt->fetch();

if (!$user) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'No account found with that username and WhatsApp number.'
    ];
    redirect('pages/forgot-password.php');
}

// Update password
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

try {
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->execute([$hashed_password, $user['id']]);
    
    // Send WhatsApp notification to admin
    $message = "Password reset for AdeliaID account:\nUsername: $username\n\nThis was initiated via WhatsApp number: $whatsapp";
    sendWhatsAppNotification(ADMIN_WHATSAPP, $message);
    
    $_SESSION['flash_message'] = [
        'type' => 'success',
        'text' => 'Password reset successfully. You can now login with your new password.'
    ];
    redirect('pages/login.php');
} catch (PDOException $e) {
    $_SESSION['flash_message'] = [
        'type' => 'error',
        'text' => 'Password reset failed. Please try again.'
    ];
    redirect('pages/forgot-password.php');
}
?>