<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

$page_title = 'Forgot Password';
include '../includes/header.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect(isAdmin() ? 'pages/dashboard/' : 'index.php');
}
?>

<div class="auth-container">
    <div class="auth-card">
        <h2>Reset Your Password</h2>
        
        <form action="../processes/forgot-password-process.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
            
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="whatsapp">WhatsApp Number</label>
                <input type="text" id="whatsapp" name="whatsapp" class="form-control" required>
                <small class="text-muted">Must match the number registered with your account</small>
            </div>
            
            <div class="form-group">
                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-block">Reset Password</button>
            </div>
            
            <div class="text-center mt-3">
                Remember your password? <a href="login.php" class="link">Login here</a>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>