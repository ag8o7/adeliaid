<?php
require_once '../../includes/config.php';
require_once '../../includes/auth.php';

// Only admin can access this page
if (!isAdmin()) {
    redirect('../../login.php');
}

$page_title = 'Admin Dashboard';
$dashboard = true;
include '../../includes/header.php';

// Get stats
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$activeUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'")->fetchColumn();
$pendingUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'pending'")->fetchColumn();
?>

<div class="dashboard-main">
    <h1>Admin Dashboard</h1>
    
    <div class="dashboard-stats">
        <div class="stat-card">
            <h3>Total Users</h3>
            <p><?php echo $totalUsers; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>Active Users</h3>
            <p><?php echo $activeUsers; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>Pending Approvals</h3>
            <p><?php echo $pendingUsers; ?></p>
        </div>
    </div>
    
    <div class="dashboard-card">
        <h2>Recent Activity</h2>
        
        <?php
        $logs = $pdo->query("
            SELECT l.*, u.username as admin_username, t.username as target_username 
            FROM admin_logs l
            LEFT JOIN users u ON l.admin_id = u.id
            LEFT JOIN users t ON l.target_user_id = t.id
            ORDER BY l.created_at DESC
            LIMIT 10
        ")->fetchAll(PDO::FETCH_ASSOC);
        ?>
        
        <?php if (count($logs) > 0): ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Admin</th>
                        <th>Action</th>
                        <th>Target</th>
                        <th>Details</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($log['admin_username'] ?? 'System'); ?></td>
                        <td><?php echo htmlspecialchars($log['action']); ?></td>
                        <td><?php echo htmlspecialchars($log['target_username'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($log['details'] ?? ''); ?></td>
                        <td><?php echo date('M j, Y H:i', strtotime($log['created_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <p>No recent activity found.</p>
        <?php endif; ?>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>