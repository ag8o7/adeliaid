<?php
require_once '../../includes/config.php';
require_once '../../includes/auth.php';

// Only admin can access this page
if (!isAdmin()) {
    redirect('../../login.php');
}

$page_title = 'Manage Users';
$dashboard = true;
include '../../includes/header.php';

// Get current page for pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Get filter values
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Build query
$query = "SELECT * FROM users WHERE 1=1";
$params = [];

if (!empty($status_filter)) {
    $query .= " AND status = ?";
    $params[] = $status_filter;
}

if (!empty($search_query)) {
    $query .= " AND (username LIKE ? OR whatsapp LIKE ?)";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
}

// Get total count for pagination
$count_query = "SELECT COUNT(*) FROM (" . $query . ") AS total";
$stmt = $pdo->prepare($count_query);
$stmt->execute($params);
$total_users = $stmt->fetchColumn();

// Add pagination to main query
$query .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

// Get users
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="dashboard-main">
    <h1>Manage Users</h1>
    
    <div class="dashboard-card">
        <div class="search-filter">
            <div class="search-box">
                <form method="GET" action="">
                    <input type="text" name="search" placeholder="Search users..." 
                           value="<?php echo htmlspecialchars($search_query); ?>" class="form-control">
                    <button type="submit" class="btn" style="margin-top: 0.5rem;">Search</button>
                </form>
            </div>
            
            <div class="filter-group">
                <form method="GET" action="">
                    <select name="status" class="form-control" onchange="this.form.submit()">
                        <option value="">All Statuses</option>
                        <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="rejected" <?php echo $status_filter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        <option value="inactive" <?php echo $status_filter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                    <?php if (!empty($search_query)): ?>
                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                    <?php endif; ?>
                </form>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>WhatsApp</th>
                        <th>Status</th>
                        <th>Registered</th>
                        <th>Last Activity</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['whatsapp']); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $user['status']; ?>">
                                <?php echo ucfirst($user['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                        <td>
                            <?php echo $user['last_activity'] ? 
                                date('M j, Y H:i', strtotime($user['last_activity'])) : 'Never'; ?>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <?php if ($user['status'] === 'pending'): ?>
                                    <form action="admin-actions.php" method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="approve">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                                        <button type="submit" class="action-btn activate-btn" title="Approve">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    </form>
                                    
                                    <form action="admin-actions.php" method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="reject">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                                        <button type="submit" class="action-btn delete-btn" title="Reject">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </form>
                                <?php elseif ($user['status'] === 'active'): ?>
                                    <form action="admin-actions.php" method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="deactivate">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                                        <button type="submit" class="action-btn deactivate-btn" title="Deactivate">
                                            <i class="fas fa-ban"></i>
                                        </button>
                                    </form>
                                <?php elseif ($user['status'] === 'inactive'): ?>
                                    <form action="admin-actions.php" method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="activate">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                                        <button type="submit" class="action-btn activate-btn" title="Activate">
                                            <i class="fas fa-power-off"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                                
                                <?php if ($user['username'] !== 'admin'): ?>
                                    <form action="admin-actions.php" method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                                        <button type="submit" class="action-btn delete-btn" title="Delete" 
                                                onclick="return confirm('Are you sure you want to delete this user?');">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($total_users > $limit): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?><?php echo !empty($status_filter) ? '&status=' . urlencode($status_filter) : ''; ?><?php echo !empty($search_query) ? '&search=' . urlencode($search_query) : ''; ?>">Previous</a>
            <?php endif; ?>
            
            <?php
            $total_pages = ceil($total_users / $limit);
            $start_page = max(1, $page - 2);
            $end_page = min($total_pages, $page + 2);
            
            if ($start_page > 1) {
                echo '<a href="?page=1' . (!empty($status_filter) ? '&status=' . urlencode($status_filter) : '') . (!empty($search_query) ? '&search=' . urlencode($search_query) : '') . '">1</a>';
                if ($start_page > 2) echo '<span>...</span>';
            }
            
            for ($i = $start_page; $i <= $end_page; $i++) {
                if ($i == $page) {
                    echo '<a class="active">' . $i . '</a>';
                } else {
                    echo '<a href="?page=' . $i . (!empty($status_filter) ? '&status=' . urlencode($status_filter) : '') . (!empty($search_query) ? '&search=' . urlencode($search_query) : '') . '">' . $i . '</a>';
                }
            }
            
            if ($end_page < $total_pages) {
                if ($end_page < $total_pages - 1) echo '<span>...</span>';
                echo '<a href="?page=' . $total_pages . (!empty($status_filter) ? '&status=' . urlencode($status_filter) : '') . (!empty($search_query) ? '&search=' . urlencode($search_query) : '') . '">' . $total_pages . '</a>';
            }
            ?>
            
            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?><?php echo !empty($status_filter) ? '&status=' . urlencode($status_filter) : ''; ?><?php echo !empty($search_query) ? '&search=' . urlencode($search_query) : ''; ?>">Next</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>