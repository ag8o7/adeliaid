<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

$page_title = 'Register';
include '../includes/header.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect(isAdmin() ? 'pages/dashboard/' : 'index.php');
}
?>

<div class="auth-container">
    <div class="auth-card">
        <h2>Create AdeliaID Account</h2>
        
        <form action="../processes/register-process.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
            
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" required>
                <small class="text-muted">This will be your login ID</small>
            </div>
            
            <div class="form-group">
                <label for="whatsapp">WhatsApp Number</label>
                <input type="text" id="whatsapp" name="whatsapp" class="form-control" required>
                <small class="text-muted">Format: 6285607063906 (without + or spaces)</small>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
                <small class="text-muted">Minimum 8 characters</small>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-block">Register</button>
            </div>
            
            <div class="text-center mt-3">
                Already have an account? <a href="login.php" class="link">Login here</a>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>