<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

$page_title = 'Login';
include '../includes/header.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect(isAdmin() ? 'pages/dashboard/' : 'index.php');
}
?>

<div class="auth-container">
    <div class="auth-card">
        <h2>Login to AdeliaID</h2>
        
        <form action="../processes/login-process.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
            
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-block">Login</button>
            </div>
            
            <div class="text-center mt-3">
                <a href="forgot-password.php" class="link">Forgot Password?</a>
            </div>
            
            <div class="text-center mt-3">
                Don't have an account? <a href="register.php" class="link">Register here</a>
            </div>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>