        </main>

        <footer class="main-footer">
            <div class="container">
                <p>&copy; <?php echo date('Y'); ?> AdeliaID. All rights reserved.</p>
            </div>
        </footer>

        <script src="../assets/js/main.js"></script>
        <?php if (isset($dashboard) && $dashboard): ?>
        <script src="../assets/js/dashboard.js"></script>
        <?php endif; ?>
    </body>
</html>