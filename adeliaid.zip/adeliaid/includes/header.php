<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AdeliaID - <?php echo $page_title ?? 'Welcome'; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <?php if (isset($dashboard) && $dashboard): ?>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <?php endif; ?>
</head>
<body>
    <?php if (isset($dashboard) && $dashboard): ?>
    <header class="dashboard-header">
        <div class="logo">
            <img src="../assets/images/logo.png" alt="AdeliaID Logo">
            <span>Admin Dashboard</span>
        </div>
        <nav>
            <ul>
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="approvals.php"><i class="fas fa-check-circle"></i> Approvals</a></li>
                <li><a href="../processes/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
    </header>
    <?php else: ?>
    <header class="main-header">
        <div class="container">
            <div class="logo">
                <img src="assets/images/logo.png" alt="AdeliaID Logo">
                <h1>AdeliaID</h1>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <?php if (isLoggedIn()): ?>
                        <li><a href="processes/logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a href="pages/login.php">Login</a></li>
                        <li><a href="pages/register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    <?php endif; ?>

    <main>
        <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="flash-message <?php echo $_SESSION['flash_message']['type']; ?>">
            <?php echo $_SESSION['flash_message']['text']; ?>
            <?php unset($_SESSION['flash_message']); ?>
        </div>
        <?php endif; ?>