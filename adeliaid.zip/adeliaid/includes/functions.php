<?php
function redirect($url) {
    header("Location: $url");
    exit();
}

function isLoggedIn() {
    if (isset($_SESSION['user_id'])) {
        // Check session timeout
        if (isset($_SESSION['last_activity']) && 
            (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
            session_unset();
            session_destroy();
            return false;
        }
        $_SESSION['last_activity'] = time();
        return true;
    }
    return false;
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

function sendWhatsAppNotification($number, $message) {
    // In a real implementation, you would use a WhatsApp API like Twilio
    $url = "https://api.whatsapp.com/send?phone=" . $number . "&text=" . urlencode($message);
    
    // For demo purposes, we'll just log this
    error_log("WhatsApp notification to $number: $message");
    
    // In production, you would actually send the message using an API
    // $ch = curl_init();
    // curl_setopt($ch, CURLOPT_URL, "https://api.whatsappprovider.com/v1/messages");
    // curl_setopt($ch, CURLOPT_POST, 1);
    // curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    //     'phone' => $number,
    //     'message' => $message,
    //     'api_key' => WHATSAPP_API_KEY
    // ]));
    // curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // $response = curl_exec($ch);
    // curl_close($ch);
    // return $response;
}

function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
?>