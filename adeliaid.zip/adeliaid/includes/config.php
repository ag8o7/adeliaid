<?php
session_start();

// Database configuration
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'adeliaid_db');

// WhatsApp configuration
define('ADMIN_WHATSAPP', '6285607063906');
define('WHATSAPP_API_KEY', 'your_whatsapp_api_key');

// Session timeout (30 minutes)
define('SESSION_TIMEOUT', 1800);

// Connect to database
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Include functions
require_once 'functions.php';
?>