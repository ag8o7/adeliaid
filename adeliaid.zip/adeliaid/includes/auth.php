<?php
require_once 'config.php';

// Check if user should be logged out due to inactivity
if (isLoggedIn()) {
    // Update last activity in database
    $stmt = $pdo->prepare("UPDATE users SET last_activity = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    // Redirect admin to dashboard
    if (isAdmin() && basename($_SERVER['PHP_SELF']) != 'dashboard.php') {
        redirect('pages/dashboard/');
    }
    
    // Redirect regular users away from auth pages
    $auth_pages = ['login.php', 'register.php', 'forgot-password.php'];
    if (in_array(basename($_SERVER['PHP_SELF']), $auth_pages)) {
        redirect('index.php');
    }
} else {
    // Redirect to login if trying to access protected pages
    $protected_pages = ['dashboard/', 'profile.php'];
    foreach ($protected_pages as $page) {
        if (strpos($_SERVER['PHP_SELF'], $page) !== false) {
            redirect('../login.php');
        }
    }
}
?>