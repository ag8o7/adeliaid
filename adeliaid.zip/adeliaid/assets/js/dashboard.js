document.addEventListener('DOMContentLoaded', function() {
    // Confirm before critical actions
    const deleteButtons = document.querySelectorAll('.delete-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to perform this action?')) {
                e.preventDefault();
            }
        });
    });

    // Table row click functionality
    const tableRows = document.querySelectorAll('.table tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('click', function(e) {
            // Ignore if clicked on a button or link
            if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A' || 
                e.target.parentElement.tagName === 'BUTTON' || 
                e.target.parentElement.tagName === 'A') {
                return;
            }
            
            // Get user ID from data attribute or other source
            const userId = this.getAttribute('data-user-id');
            if (userId) {
                window.location.href = `user-details.php?id=${userId}`;
            }
        });
    });

    // Search functionality
    const searchInput = document.querySelector('.search-box input');
    if (searchInput) {
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                this.form.submit();
            }
        });
    }
});