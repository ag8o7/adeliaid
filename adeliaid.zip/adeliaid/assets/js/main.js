document.addEventListener('DOMContentLoaded', function() {
    // Flash message auto hide
    const flashMessage = document.querySelector('.flash-message');
    if (flashMessage) {
        setTimeout(() => {
            flashMessage.style.opacity = '0';
            setTimeout(() => flashMessage.remove(), 500);
        }, 5000);
    }

    // Password toggle functionality
    const togglePassword = document.querySelectorAll('.toggle-password');
    togglePassword.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.previousElementSibling;
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            this.querySelector('i').classList.toggle('fa-eye');
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    });

    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const passwordInputs = this.querySelectorAll('input[type="password"]');
            if (passwordInputs.length > 1 && 
                passwordInputs[0].value !== passwordInputs[1].value) {
                e.preventDefault();
                alert('Passwords do not match!');
                passwordInputs[0].focus();
            }
        });
    });
});